from django.apps import AppConfig


class ClinicalsappConfig(AppConfig):
    name = 'clinicalsApp'
