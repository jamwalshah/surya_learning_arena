from django.apps import AppConfig


class CookiesappConfig(AppConfig):
    name = 'cookiesApp'
