from django.apps import AppConfig


class FbvappConfig(AppConfig):
    name = 'fbvApp'
