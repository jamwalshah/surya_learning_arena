from django.apps import AppConfig


class CbvappConfig(AppConfig):
    name = 'cbvApp'
